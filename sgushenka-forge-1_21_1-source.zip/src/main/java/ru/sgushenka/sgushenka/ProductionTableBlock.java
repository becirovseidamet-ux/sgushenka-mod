package ru.sgushenka.sgushenka;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import java.util.Map;
import java.util.WeakHashMap;

public class ProductionTableBlock extends Block {
    private static final Map<String, Integer> PROGRESS = new WeakHashMap<>();

    public ProductionTableBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        String key = player.getUUID() + ":" + hit.getBlockPos().asLong();
        int count = Math.min(5, PROGRESS.getOrDefault(key, 0) + 1);
        if (count >= 5) {
            PROGRESS.remove(key);
            if (player instanceof ServerPlayer serverPlayer) {
                ItemStack can = new ItemStack(SgushenkaMod.SGUSHENKA.get());
                if (!serverPlayer.getInventory().add(can)) serverPlayer.drop(can, false);
                serverPlayer.displayClientMessage(Component.literal("Производство завершено! Получена сгущёнка."), true);
            }
        } else {
            PROGRESS.put(key, count);
            player.displayClientMessage(Component.literal("Добыча: " + count + "/5"), true);
        }
        return InteractionResult.CONSUME;
    }
}
