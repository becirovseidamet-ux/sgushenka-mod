package ru.sgushenka.sgushenka;

import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(SgushenkaMod.MODID)
public class SgushenkaMod {
    public static final String MODID = "sgushenka";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);

    public static final RegistryObject<Item> SGUSHENKA = ITEMS.register("sgushenka",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
            .nutrition(6).saturationModifier(0.6F).alwaysEdible().build())));

    public static final RegistryObject<Block> PRODUCTION_TABLE = BLOCKS.register("production_table",
        () -> new ProductionTableBlock(BlockBehaviour.Properties.of()
            .mapColor(MapColor.METAL).strength(2.5F).requiresCorrectToolForDrops()));

    public SgushenkaMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        BLOCKS.register(bus);
        ITEMS.register("production_table", () -> new BlockItem(PRODUCTION_TABLE.get(), new Item.Properties()));
    }
}
